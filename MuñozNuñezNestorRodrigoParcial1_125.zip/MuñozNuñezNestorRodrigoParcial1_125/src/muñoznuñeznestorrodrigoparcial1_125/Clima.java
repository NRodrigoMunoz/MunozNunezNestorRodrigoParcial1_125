package muñoznuñeznestorrodrigoparcial1_125;

public enum Clima {
    PRIMAVERA,
    VERANO,
    OTOÑO,
    INVIERNO
}
