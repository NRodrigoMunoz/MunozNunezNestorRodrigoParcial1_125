package muñoznuñeznestorrodrigoparcial1_125;
public interface Desmalezar {
    void podar();
}
