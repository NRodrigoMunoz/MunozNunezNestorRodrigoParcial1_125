package muñoznuñeznestorrodrigoparcial1_125;
public class Arbol extends Planta implements Desmalezar{
    private double alturaMaxima;

    public Arbol(double alturaMaxima, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public void podar() {
        System.out.println("El arbol ha sido podado");
    }

    
    
    @Override
    public String toString() {
        return super.toString() + " AlturaMaxima: " + alturaMaxima;
    }
    
    
}
