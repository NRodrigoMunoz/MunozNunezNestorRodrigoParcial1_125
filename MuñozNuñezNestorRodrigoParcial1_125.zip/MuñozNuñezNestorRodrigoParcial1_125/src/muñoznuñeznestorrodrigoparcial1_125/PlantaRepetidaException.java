package muñoznuñeznestorrodrigoparcial1_125;
public class PlantaRepetidaException extends RuntimeException{
    private static final String MESSAGE = "La planta se encuentra repetida.";
    
    public PlantaRepetidaException(){
        super(MESSAGE);
    }
    
}
