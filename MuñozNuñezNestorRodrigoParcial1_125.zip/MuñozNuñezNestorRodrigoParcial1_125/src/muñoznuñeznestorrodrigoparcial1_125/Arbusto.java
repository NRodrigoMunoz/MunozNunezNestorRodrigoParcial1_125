package muñoznuñeznestorrodrigoparcial1_125;
public class Arbusto extends Planta implements Desmalezar{
    private static final int MAX_DENSIDAD = 10;
    private static final int MIN_DENSIDAD = 1;
    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = valoresDensidadPermitidos(densidadFollaje);
    }

    @Override
    public void podar() {
        System.out.println("El arbusto ah sido podado.");
    }

    private int valoresDensidadPermitidos(int densidad){
        if (densidad > MIN_DENSIDAD || densidad < MAX_DENSIDAD) {
            return densidad;
        }
        return -1;
    }
    
    @Override
    public String toString() {
        return super.toString() + " Densidad: " + densidadFollaje;
    }
    
    
}
